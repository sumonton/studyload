package com.atguigu.mp.mapper;

import com.atguigu.mp.beans.User;
import com.baomidou.mybatisplus.mapper.BaseMapper;

public interface UserMapper  extends BaseMapper<User>{

}
