package com.atguigu.mp.beans;

import com.baomidou.mybatisplus.annotations.KeySequence;

@KeySequence(value="seq_user",clazz=Integer.class)
public abstract class Parent {

}
